import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Users, Heart, CheckCircle, ArrowRight } from 'lucide-react';
import { useAuth } from '../App';
import { UserRole } from '../types';

export const Registration = ({ setPage }: { setPage: (p: string) => void }) => {
  const { login } = useAuth();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    church: '',
    reason: ''
  });

  const roles = [
    {
      id: 'evangelist',
      title: 'Evangelista',
      icon: Users,
      desc: 'Participe ativamente dos eventos, pregando o evangelho nas ruas e comunidades.',
      color: 'blue'
    },
    {
      id: 'leader',
      title: 'Líder de Equipe',
      icon: Shield,
      desc: 'Lidere, treine e coordene equipes de evangelismo em campo.',
      color: 'purple'
    },
    {
      id: 'intercessor',
      title: 'Intercessor',
      icon: Heart,
      desc: 'Sustente o ministério em oração e receba pedidos específicos da equipe.',
      color: 'pink'
    }
  ];

  const handleRoleSelect = (role: string) => {
    setSelectedRole(role as UserRole);
    setStep(2);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setTimeout(() => {
      // Auto-login for demo purposes
      if (selectedRole) {
        login(selectedRole);
        setPage('Dashboard');
      }
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-extrabold text-slate-900 mb-4">Junte-se ao Movimento</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Escolha como você deseja servir no Reino. Cada função é essencial para alcançarmos nossa cidade.
        </p>
      </div>

      {step === 1 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {roles.map((role) => (
            <motion.button
              key={role.id}
              whileHover={{ y: -5 }}
              onClick={() => handleRoleSelect(role.id)}
              className={`text-left p-6 rounded-2xl border-2 transition-all duration-300 bg-white shadow-sm hover:shadow-xl ${
                role.color === 'blue' ? 'border-blue-100 hover:border-blue-500' :
                role.color === 'purple' ? 'border-purple-100 hover:border-purple-500' :
                'border-pink-100 hover:border-pink-500'
              }`}
            >
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center mb-6 ${
                 role.color === 'blue' ? 'bg-blue-50 text-blue-600' :
                 role.color === 'purple' ? 'bg-purple-50 text-purple-600' :
                 'bg-pink-50 text-pink-600'
              }`}>
                <role.icon className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{role.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{role.desc}</p>
              <div className="mt-6 flex items-center text-sm font-semibold text-slate-900">
                Inscrever-se <ArrowRight className="w-4 h-4 ml-2" />
              </div>
            </motion.button>
          ))}
        </div>
      )}

      {step === 2 && selectedRole && (
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl shadow-xl border border-slate-100 p-8 max-w-2xl mx-auto"
        >
          <div className="flex items-center gap-3 mb-8 pb-6 border-b border-slate-100">
            <button onClick={() => setStep(1)} className="text-sm text-slate-400 hover:text-slate-600">Voltar</button>
            <div className="flex-1 text-center">
              <span className="uppercase text-xs font-bold text-slate-400 tracking-wider">Inscrição para</span>
              <h2 className="text-2xl font-bold text-slate-900 capitalize">
                {roles.find(r => r.id === selectedRole)?.title}
              </h2>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Nome Completo</label>
                <input 
                  required
                  type="text" 
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="Seu nome"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Email</label>
                <input 
                  required
                  type="email" 
                  value={formData.email}
                  onChange={e => setFormData({...formData, email: e.target.value})}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="seu@email.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Igreja que frequenta</label>
              <input 
                required
                type="text" 
                value={formData.church}
                onChange={e => setFormData({...formData, church: e.target.value})}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                placeholder="Nome da igreja"
              />
            </div>

            {(selectedRole === 'leader' || selectedRole === 'evangelist') && (
               <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">Experiência Prévia</label>
                <textarea 
                  value={formData.reason}
                  onChange={e => setFormData({...formData, reason: e.target.value})}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 focus:outline-none h-24 resize-none"
                  placeholder="Conte brevemente sua experiência com evangelismo..."
                />
              </div>
            )}

            <button 
              type="submit"
              className="w-full py-4 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              <CheckCircle className="w-5 h-5" />
              Confirmar Inscrição
            </button>
          </form>
        </motion.div>
      )}
    </div>
  );
};